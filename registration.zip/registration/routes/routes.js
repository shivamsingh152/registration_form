const express = require('express');
const router = express.Router();
const Users = require('../models/users');


router.get("/", (req, res) => {
  Users.find()
    .catch((err)=>{
      console.log(err)
    })
    .then((users)=>{
      res.render('index',{
        users: users,
      })
    })
  });
  
  router.get("/add", (req, res) => {
    res.render("registration");
  });
  

  router.post("/add", (req, res) => {
    const user = new Users({
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      email: req.body.email,
      country: req.body.country,
      state: req.body.state,
      city: req.body.city,
      gender: req.body.gender,
      dob: req.body.dob,
      age: req.body.age,
    });
     user.save()
    .then(()=>{
      res.redirect('/')
    })
    .catch((err)=>{
          console.log(err)
        })
  })
 

module.exports = router;
