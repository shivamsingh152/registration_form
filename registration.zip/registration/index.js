const express = require("express");
const mongoose = require('mongoose');
const path = require("path");

const app = express();

const url = 5000;

app.listen(url, () => {
  console.log(`server is listening at port http://localhost:${url}`);
});

mongoose.connect('mongodb://localhost:27017/dtb')
.then(()=>{
    console.log('connected');
})
.catch((err)=>{
    console.log(err);
})

const static_path = path.join(__dirname, "/public");

app.use(express.static(static_path));

app.set("view engine", "ejs");

app.use(express.urlencoded({ extended: false }));
app.use(express.json());


app.use('', require('./routes/routes'))